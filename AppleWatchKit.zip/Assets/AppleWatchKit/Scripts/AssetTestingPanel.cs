﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.InteropServices;

/// <summary>
/// The Haptic sound to play on the watch.
/// </summary>
public enum HapticType
{
	Notification = 0,
	DirectionUp = 1,
	DirectionDown = 2,
	Success = 3,
	Failure = 4,
	Retry = 5,
	Start = 6,
	Stop = 7,
	Click = 8
};

//================================================================
//Provides access to test the various features of the asset 
//================================================================
public class AssetTestingPanel : MonoBehaviour 
{
	//The two pages of the app containing all of the controls of the app
	public GameObject page1, page2;
	//Text that displays the heart rate that is recorded from the watch
	public Text heartRateDescriptionText;
	//Communicates what pressing the heart rate button will do
	public Text heartRateStatusText;
	//Text that displays the step count that was sent from the watch
	public Text pedometerDescriptionText;
	//Communicates what pressing the pedometer button will do
	public Text pedometerStatusText;
	//Text that displays the step count that was sent from the watch
	public Text crownDataDescriptionText;
	//Communicates what pressing the pedometer button will do
	public Text crownDataStatusText;
	//Displays any messages received from the watch
	public Text receivedMessageText;
	//Text that displays the current hapticType
	public Text hapticTypeText;

	//The current haptic sound to play if a trigger is sent to the watch
	private HapticType currentHapticType;
	//A reference for when the user requests to display the keyboard
	private TouchScreenKeyboard keyboard;
	//A bool to determine if the heart rate is currently recording or not
	private bool isRecordingHeartRate = false;
	//A bool to determine if the pedometer is currently streaming or not
	private bool isStreamingPedometer = false;
	//A bool to determine if the pedometer is currently streaming or not
	private bool isStreamingCrownData = false;
	//The max length of a message sent to the watch
	private const int MAX_MESSAGE_LENGTH = 8;

	private const float MESSAGE_TEXT_UPDATE_INTERVAL = 2.0f;
	private const float HEART_RATE_UPDATE_INTERVAL = 1.0f;
	private const float PEDOMETER_UPDATE_INTERVAL = 1.0f;
	private const float CROWN_POSITION_UPDATE_INTERVAL = 0.25f;

	//Methods called from the Xcode plugin
	#if UNITY_IPHONE
	[DllImport("__Internal")]
	//Returns heart rate received by the watch
	public static extern double GetHeartRateFromWatch();
	[DllImport("__Internal")]
	//Returns step count received by the watch
	public static extern double GetStepCountFromWatch();
	[DllImport("__Internal")]
	//Starts recording the heart rate from the watch
	public static extern void StartRecordingHeartRate ();
	[DllImport("__Internal")]
	//Stops recording the heart rate from the watch
	public static extern void StopRecordingHeartRate ();
	[DllImport("__Internal")]
	//Starts streaming the pedometer from the watch
	public static extern void StartStreamingPedometer ();
	[DllImport("__Internal")]
	//Stops streaming the pedometer from the watch
	public static extern void StopStreamingPedometer ();
	[DllImport("__Internal")]
	//Sends an input message to the watch
	public static extern void SendInputToXcode (string inputMessage);
	[DllImport("__Internal")]
	//Sends a message to the watch
	public static extern void SendMessageToXcode (string message);
	[DllImport("__Internal")]
	//Sends a file name to the watch that will display the image if the 
	//name matches a file that is included in the build
	public static extern void SendImageFileNameToWatch (string fileName);
	[DllImport("__Internal")]
	//Gets a string from the watch
	public static extern string GetButtonPressFromWatch ();
	[DllImport("__Internal")]
	//Gets a string from the watch
	public static extern string GetCrownDataFromWatch ();
	[DllImport("__Internal")]
	//Sends an image to the watch
	public static extern void SendImageToWatch (byte[] texture, int width, int height);
	#endif

	void Start ()
	{
		//Set the Haptic type to the "notification" sound haptic type
		SetHapticType(0);
		//Invoke a method that checks for new messages from the watch, every 2 seconds
		InvokeRepeating ("UpdateMessageText", 2.0f, MESSAGE_TEXT_UPDATE_INTERVAL);
	}

	/// <summary>
	/// Switches to the next page
	/// </summary>
	public void NextPage()
	{
		page2.SetActive (true);
		page1.SetActive (false);
	}

	/// <summary>
	/// Switches to the previous page
	/// </summary>
	public void PreviousPage()
	{
		page1.SetActive (true);
		page2.SetActive (false);
	}

	/// <summary>
	/// Sends the image filename to the watch. The watch will try to find this image and display it as the background of the watch
	/// Please note: the image must be included in the Xcode build and the fileName must match
	/// the file name of the image included in the Xcode build.
	/// </summary>
	/// <param name="fileName">The filename of the image you want to have displayed on the watch.</param>
	public void SendImage(string fileName)
	{
		SendImageFileNameToWatch (fileName);
	}

	/// <summary>
	/// Sends the image to the watch.
	/// </summary>
	/// <param name="textureToSend">A reference to the texture you are sending.</param>
	public void SendImage(Texture2D textureToSend)
	{
		//Get the byte information
		byte[] imageData = textureToSend.EncodeToPNG ();
		//Send to the watch, include the width and height
		SendImageToWatch (imageData,textureToSend.width, textureToSend.height);
	}

	/// <summary>
	/// Changes the status of the Heart Rate Test
	/// </summary>
	public void ChangeHeartRateTest()
	{
		//If not currently recording the heart rate
		if (!isRecordingHeartRate) 
		{
			isRecordingHeartRate = true;
			//Invoke a method that checks for new heart rate values every second
			InvokeRepeating ("UpdateHeartRateText", 0.0001f, HEART_RATE_UPDATE_INTERVAL);
			//Starts the heart rate recording on the watch
			StartHeartRate ();
			heartRateStatusText.text = "- Tap to stop recording Heart Rate -";
		}
		else 
		{
			isRecordingHeartRate = false;
			//Stops the heart rate recording on the watch
			StopHeartRate ();
			heartRateStatusText.text = "- Tap to record Heart Rate -";
			//Cancel the Invoked method
			CancelInvoke ("UpdateHeartRateText");
			heartRateDescriptionText.text = "Heart Rate: 0";
		}
	}

	/// <summary>
	/// Updates the heart rate text.
	/// </summary>
	public void UpdateHeartRateText()
	{
		#if UNITY_IPHONE
		//Get the value from the watch
		double returnedValue = GetHeartRateFromWatch();
		//If it's greater than 0
		if(returnedValue > 0)
		{
			//Then show it on the phone
			heartRateDescriptionText.text = "Heart Rate: " + returnedValue;
		}
		print("Returned: " + returnedValue);
		#endif
	}

	/// <summary>
	/// Starts the heart rate on the watch.
	/// </summary>
	public void StartHeartRate()
	{
		#if UNITY_IPHONE
		if (Application.platform == RuntimePlatform.IPhonePlayer) 
		{
			StartRecordingHeartRate();
		}
		#endif
	}

	/// <summary>
	/// Stops the heart rate on the watch.
	/// </summary>
	private void StopHeartRate()
	{
		#if UNITY_IPHONE
		if (Application.platform == RuntimePlatform.IPhonePlayer) 
		{
			StopRecordingHeartRate();
		}
		#endif
	}

	/// <summary>
	/// Changes the status of the Pedometer Test
	/// </summary>
	public void ChangePedometerTest()
	{
		//If not currently streaming the pedometer info
		if (!isStreamingPedometer) 
		{
			isStreamingPedometer = true;
			//Invoke a method that checks for new pedometer data values every second
			InvokeRepeating ("UpdatePedometerText", 0.0001f, PEDOMETER_UPDATE_INTERVAL);
			//Starts the pedometer on the watch
			StartPedometer ();
			pedometerStatusText.text = "- Tap to stop streaming Pedometer -";
		}
		else 
		{
			isStreamingPedometer = false;
			//Stops the pedometer on the watch
			StopPedometer ();
			pedometerStatusText.text = "- Tap to start streaming Pedometer -";
			//Cancel the Invoked method
			CancelInvoke ("UpdatePedometerText");
			pedometerDescriptionText.text = "Steps: 0";
		}
	}

	/// <summary>
	/// Updates the pedometer text.
	/// </summary>
	public void UpdatePedometerText()
	{
		#if UNITY_IPHONE
		//Get the value from the watch
		double returnedValue = GetStepCountFromWatch();
		//If it's greater than 0
		if(returnedValue > 0)
		{
			//Then show it on the phone
			pedometerDescriptionText.text = "Steps: " + returnedValue;
		}
		print("Returned: " + returnedValue);
		#endif
	}

	/// <summary>
	/// Starts the pedometer on the watch.
	/// </summary>
	public void StartPedometer()
	{
		#if UNITY_IPHONE
		if (Application.platform == RuntimePlatform.IPhonePlayer) 
		{
			StartStreamingPedometer();
		}
		#endif
	}

	/// <summary>
	/// Stops the pedometer on the watch.
	/// </summary>
	private void StopPedometer()
	{
		#if UNITY_IPHONE
		if (Application.platform == RuntimePlatform.IPhonePlayer) 
		{
			StopStreamingPedometer();
		}
		#endif
	}

	/// <summary>
	/// Changes the status of the Pedometer Test
	/// </summary>
	public void ChangeCrownDataStatus()
	{
		//If not currently streaming the pedometer info
		if (!isStreamingCrownData) 
		{
			isStreamingCrownData = true;
			//Invoke a method that checks for new pedometer data values every second
			InvokeRepeating ("UpdateCrownDataText", 0.0001f, CROWN_POSITION_UPDATE_INTERVAL);

			crownDataDescriptionText.text = "Crown Data: IDLE";
			crownDataStatusText.text = "- Tap to stop streaming Crown Data -";
		}
		else 
		{
			isStreamingCrownData = false;

			crownDataStatusText.text = "- Tap to start streaming Crown Data -";
			//Cancel the Invoked method
			CancelInvoke ("UpdateCrownDataText");
			crownDataDescriptionText.text = "Crown Data: Off";
		}
	}

	/// <summary>
	/// Updates the pedometer text.
	/// </summary>
	public void UpdateCrownDataText()
	{
		#if UNITY_IPHONE
		//Get the value from the watch
		string crownDataResult = GetCrownDataFromWatch();
		if(crownDataResult == "IDLE")
		{
			crownDataDescriptionText.text = "Crown Data: IDLE";
		}
		else
		{
			double returnedValue = -1;
			if(double.TryParse(crownDataResult, out returnedValue))
			{
				if(returnedValue == 0)
				{
					crownDataDescriptionText.text = "Crown Data: IDLE";
				}
				else
				{
					crownDataDescriptionText.text = "Crown Data: " + returnedValue;
					print("Returned: " + returnedValue);
				}
			}
			else
			{
				print("Conversion error: " + crownDataResult);
			}
		}
		#endif
	}

	/// <summary>
	/// Updates the message text.
	/// </summary>
	public void UpdateMessageText()
	{
		#if UNITY_IPHONE
		//Get the string received from the watch
		string buttonPressReceived = GetButtonPressFromWatch();
		//If the message isn't empty
		if(buttonPressReceived != string.Empty)
		{
			//Show the message
			receivedMessageText.text = "Action Received: " + buttonPressReceived;
			print("This is the message Received: " + buttonPressReceived);
		}
		#endif
	}

	/// <summary>
	/// Opens the keyboard, allowing the user to send a message to their watch.
	/// </summary>
	public void OpenKeyboard()
	{
		keyboard = TouchScreenKeyboard.Open (string.Empty);
		StartCoroutine (WaitForKeyboardToBeFinished ());
	}

	/// <summary>
	/// Waits for keyboard to be finished.
	/// </summary>
	private IEnumerator WaitForKeyboardToBeFinished()
	{
		while (keyboard != null) 
		{
			//When the keyboard is dismissed
			if (keyboard.done) 
			{
				string textToSend = keyboard.text;
				//Check if the message is too long, if so then cut it's length down
				if (textToSend.Length > MAX_MESSAGE_LENGTH) 
				{
					textToSend = textToSend.Substring (0, MAX_MESSAGE_LENGTH);
				}
				//Send the message to Xcode
				SendMessageToXcode (textToSend);
				keyboard = null;
			}
			yield return new WaitForEndOfFrame ();
		}
		yield return new WaitForEndOfFrame ();
	}

	/// <summary>
	/// Called when button A is pressed.
	/// </summary>
	public void ButtonAPressed()
	{
		//Send input text "Button A"
		SendInputToXcode ("Button A");
	}

	/// <summary>
	/// Called when button B is pressed.
	/// </summary>
	public void ButtonBPressed()
	{
		//Send input text "Button B"
		SendInputToXcode ("Button B");
	}

	/// <summary>
	/// Set the haptic type to the next type
	/// </summary>
	public void NextHapticType()
	{
		//Convert the HapticType to int and increase it
		int currentTypeAsInt = (int)currentHapticType;
		currentTypeAsInt++;
		//if currentTypeAsInt is too high then reset it to 0
		if (currentTypeAsInt > (int)HapticType.Click) 
		{
			currentTypeAsInt = 0;
		}
		SetHapticType (currentTypeAsInt);
	}

	/// <summary>
	/// Set the haptic type to the previous type
	/// </summary>
	public void PrevHapticType()
	{
		//Convert the HapticType to int and decrease it
		int currentTypeAsInt = (int)currentHapticType;
		currentTypeAsInt--;
		//if currentTypeAsInt is too low then reset it to highest value
		if (currentTypeAsInt < 0) 
		{
			currentTypeAsInt = (int)HapticType.Click;
		}
		SetHapticType (currentTypeAsInt);
	}

	/// <summary>
	/// Sets the haptic type and updates the haptic text
	/// </summary>
	/// <param name="currentTypeAsInt">Current type as int.</param>
	private void SetHapticType(int currentTypeAsInt)
	{
		//Convert the int back to a HapticType
		currentHapticType = (HapticType)currentTypeAsInt;
		//Update the text field
		hapticTypeText.text = "Current Haptic \"" + currentHapticType + "\"";
	}

	/// <summary>
	/// Triggers the haptic effect on the watch
	/// by sending a message to the watch
	/// </summary>
	public void TriggerHapticOnWatch()
	{
		SendMessageToXcode (currentHapticType.ToString ());
	}
}

Apple Watch Kit v2.0
--------------------

By Funky Finger Productions, Inc.

Version 2.0
Tested with Unity3D 2017.4.3f1 and Xcode 9.3
Tested with iPhone 5s & 6+ running iOS 11.3
Tested with Apple Watch Sport 42mm running WatchOS 4.2.3


Description
-----------

Now you can add Apple Watch functionality to your Unity apps!

The Apple Watch Kit allows you to create Unity apps that can communicate with the Apple Watch and transfer information back and forth, including text strings, button presses, and heart rate data.

The project contains a Unity scene (WatchAssetTestScene) which provides you with various buttons, images, and text messages to test the features and functionality of the Apple Watch Kit.


Key Features
------------

� Send text strings to the watch (for sending text which the user enters on the phone)
� Send inputs to the watch (for sending button presses)
� Send messages and numbers to the phone (for sending button presses, heart rate, pedometer*, and crown rotation*)
� Send filenames to the watch (for switching between background 1 and 2 on the watch)
� Send images to the watch (for sending background 3 or background 4 to the watch)
� Fully-commented C# scripts
� Fully-commented Objective C scripts

* = New in version 2.0


Support
-------

Questions, comments, or bug reports should be emailed to: unity@funkyfinger.ca


Legal Information
-----------------

The Arimo font is licensed under the Apache License, Version 2.0 (free for personal and commercial use, modification and redistribution allowed).
Apple Watch Kit is an independent application and has not been authorized, sponsored, or otherwise approved by Apple Inc. Apple Watch� and iPhone� are trademarks of Apple Inc. registered in the US and other countries. 


Assumptions
-----------

This asset assumes that you are familiar with setting up provision profiles, making App IDs, and deploying builds to the iPhone and Apple Watch.
It is also assumed that you know how to add capabilities to App IDs, as the Apple Watch Kit uses the HealthKit capability to read the user�s heart rate.
This asset also assumes that you know what targets are and how to change them.

If you are unsure how to turn on capabilities on your application, please visit the following link:
https://developer.apple.com/library/content/documentation/IDEs/Conceptual/AppStoreDistributionTutorial/AddingCapabilities/AddingCapabilities.html.

For information on creating provision profiles and App IDs, please visit the following link:
https://developer.apple.com/library/content/documentation/IDEs/Conceptual/AppDistributionGuide/MaintainingProfiles/MaintainingProfiles.html


Project Structure
-----------------

This is a quick overview of the subfolder structure within the Assets folder of the Unity project:

� Editor - Contains the XcodeConfig.cs script for handling some post-build code which changes some settings in the Xcode project and automatically creates the watch app and extension. This script executes when you press build in Unity.

� Fonts - Any fonts used in the app or watch app are stored here.

� Images
   o App Images - All graphics used for the iPhone app are in here.
   o Backgrounds - All graphics used for the backgrounds are in here.

� Plugins
   o iOS - Contains the Header file and .mm file for UnityToXcodeBridge
   o WatchAppFiles - All files used for the Watch App and Watch App Extension. NOTE: Be careful when making changes to this folder; if any files are added or removed be sure to add or remove any references to them in XcodeConfig.cs

� Scenes - The WatchAssetTestScene scene is in here.

� Scripts - All other scripts are in this folder.

 
Scripts and Xcode Files
-----------------------

All scripts are fully commented and have header documentation explaining their purpose, but here is a quick overview:

� AssetTestingPanel.cs - Provides C# methods for calling the various native functions on the Apple Watch. Allows you to tap on button A or B and displays the correct button pressed on the watch. Allows you to tap background button 1 or 2 to change the background on the watch and press button 3 or 4 to send an image to the watch to display it as the background.
Allows you to tap the �chat bubble� button to open the keyboard and send a message to display on the watch (this message is restricted to 8 characters, but can be changed in the script). Allows you to tap the arrow keys to change the haptic notification on the watch; tapping on the music note will then play the specific notification sound on the watch.

Allows you to tap the �pulse� button to start recording the Heart Rate on the watch; the watch will display the heart rate and the phone will also display the heart rate as it receives it from the watch (note that the heart rate can take a little while to display, and that the position of the watch will affect the watch�s ability to read the user�s heart rate); tap the button again to end the recording.
Allows you to tap the �stick person� button to start the Pedometer on the watch; the watch will display the step count and the phone will also display the step count as it receives it from the watch (note that the step count can take a little while to display); tap the button again to stop the pedometer.

Allows you to tap the �crown� button to start displaying the crown rotation values (when the user rotates the crown) on the phone as it receives it from the watch (note that the crown rotation values will display with a noticeable delay); tap the button again to stop the crown rotation values displaying on the phone. An �IDLE� message will display on the phone when the crown is in an idle state.
This script also listens for numbers and text sent from the watch to the phone such as, received heart rates, received step counts, and whether button C or D was pressed on the watch.

� UnityToXcodeBridge.mm - Acts as the bridge between Unity and Xcode. Includes methods that allow the native Objective C code to be called within Unity. Establishes connection with the Apple Watch and requests authorization. Listens for messages and numbers sent from the watch. Sends messages to the watch to either display on the watch or trigger code (for example, it will send a message to the watch to instruct the watch to start or stop recording the heart rate, start or stop the pedometer, or play a notification sound). Also sends images to the Watch to change the background.

� InterfaceController.m - Controls the interface of the Apple Watch. Sends messages to the phone and records the heart rate and sends it to the phone. Streams the pedometer data and sends it to the phone. Receives crown rotation changes and sends results to the phone (note that the watch continually sends crown rotation values to the phone; enabling or disabling the crown on the phone simply changes whether the received values will be displayed or not). Receives messages and image data from the phone. Allows the user to press button C or D and sends the correct text to be displayed on the phone.

� XcodeConfig.cs - A post-build script that automatically creates the Watch App and Watch App Extension, along with changing some specific elements in the projects Plist file. Additionally, this script will add the files that are in the WatchAppFiles folder (in Plugins) to the Xcode Project being built. NOTE: Any files you add or remove in the WatchAppFiles folder will need to be updated in this script.


Other Notes
-----------

The post-build script XcodeConfig.cs located in the editor folder will set the ENABLE_BITCODE property to false; this may not be necessary for everyone, and therefore this code can be commented out to stop ENABLE_BITCODE from being set to false.

Additionally, the ConfigurePhonePlistFile method in the XcodeConfig.cs script will add descriptions for NSHealthShareUsageDescription and NSHealthUpdateUsageDescription to the project�s Plist document. If you are not using HealthKit then the entire ConfigurePhonePlistFile method can be commented out.


Known Issues
------------

When using the test application for the first time a number of permission prompts will appear in order for the user to grant the necessary permissions for the application to function properly. If the watch application is running at the same time as the phone application and the phone displays the Motion & Fitness permission request, the watch application will crash when the user selects either �Don�t Allow� or �OK�. The watch application can then be relaunched by the user and will operate properly (assuming all necessary permissions have been granted).

 
Using the Simulator
-------------------

If you are using the simulator, change the Base SDK to Latest iOS before commencing with Step 7 of the Setup procedure (in the enclosed ReadMe PDF file). Next, set the Valid Architecture to Standard (NOT x86), close Xcode, then re-open it; you should now see a General tab located to the left of the Capabilities tab. Also note that while this asset will run on the simulator, pedometer functionality cannot be simulated.


Setup
-----

Please refer to the enclosed ReadMe PDF file for detailed step-by-step instructions.


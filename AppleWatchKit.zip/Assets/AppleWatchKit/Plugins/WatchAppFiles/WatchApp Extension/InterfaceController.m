//
// InterfaceController.m
//
// Manages and communicates with the interface of the watch
//

#import "InterfaceController.h"
#import <CoreMotion/CoreMotion.h>

@implementation InterfaceController

@synthesize imageData;

- (void)awakeWithContext:(id)context
{
    [super awakeWithContext:context];
    //Give focus to the crown sequencer to allow it to trigger rotation and idle events
    [self.crownSequencer focus];
    //Set this class as the delagate to allow the crownDidRotate and crownDidBecomeIdle
    //methods to run when the appropriate events are triggered
    self.crownSequencer.delegate = self;
}

- (void)willActivate
{
    [super willActivate];
    //Guarantees the sequencer will be in focus
    [self.crownSequencer focus];
    
    //Check if WatchConnectivity is supported by this device
    if([WCSession isSupported])
    {
        //Activate the session
        WCSession *session = [WCSession defaultSession];
        session.delegate = self;
        [session activateSession];
        //Allocate space for imageData
        self.imageData = [[NSMutableData alloc]init];
    }
    else
    {
        NSLog(@"WatchConnectivity is not supported on this device");
    }
    
    //Check if healthData is available
    if([HKHealthStore isHealthDataAvailable])
    {
        //Initialize the HealthStore
        self.healthStore = [[HKHealthStore alloc] init];
        //Set the quantityType and unit
        self.heartRateType = [HKQuantityType quantityTypeForIdentifier:HKQuantityTypeIdentifierHeartRate];
        self.heartRateUnit = [HKUnit unitFromString:@"count/min"];
        
        //Request Authorization to share some health data
        [self.healthStore requestAuthorizationToShareTypes:[NSSet setWithObject:self.heartRateType] readTypes:[NSSet setWithObject:self.heartRateType] completion:^(BOOL success, NSError *error)
        {
            if(!success)
            {
                NSLog(@"%@",error);
                [self.HeartRateLabel setText:@"ACCESS DENIED"];
            }
        }];
    }
    else
    {
        [self.HeartRateLabel setText:@"NOT Available"];
    }
    //Set heart rate to zero
    self.heartRate = 0;
    
	//Check if the pedometer has not been initialized
    if(!self.pedometer)
    {
        //Initialize the pedometer
        self.pedometer = [[CMPedometer  alloc] init];
    }
}

- (void)didDeactivate
{
    // This method is called when watch view controller is no longer visible
    [super didDeactivate];
}

/// <summary>
/// Send the current value stored in self.heartRate to the phone
/// Gets called when a new Heart rate is received.
/// </summary>
- (void)sendHeartRateToThePhone
{
    [self SendIntegerToThePhone:self.heartRate WithKey:@"returnedHeartRateValueKey"];
}

/// <summary>
/// Send the current value stored in self.stepCount to the phone
/// Gets called when the step count is updated.
/// </summary>
- (void)sendStepCountToThePhone
{
    [self SendIntegerToThePhone:self.stepCount WithKey:@"returnedStepCountValueKey"];
}

/// <summary>
/// Changes the state of the workout session
/// Gets called automatically by the HKWorkoutSession when a state change occurs
/// </summary>
/// <param name="toState">The state the session is changing to.</param>
/// <param name="fromState">The state the session was in.</param>
-(void) workoutSession:(HKWorkoutSession *)workoutSession didChangeToState:(HKWorkoutSessionState)toState fromState:(HKWorkoutSessionState)fromState date:(NSDate *)date
{
    switch (toState)
    {
        //if the state changes to the running state
        case HKWorkoutSessionStateRunning:
            //Create the streamingQuery to periodically check the heart rate on the watch
            [self createStreamingQuery];
            break;
            
        default:
            NSLog(@"UNEXPECTED STATE");
    }
}

/// <summary>
/// Creates the query and sets up the updateHandler for it
/// then returns the created query
/// </summary>
-(HKQuery*) createStreamingQuery
{
    //Setup the predicate
    NSPredicate *predicate = [HKQuery predicateForSamplesWithStartDate:[NSDate date] endDate:nil options:HKQueryOptionNone];
    
    //Initialize the query
    HKAnchoredObjectQuery *query = [[HKAnchoredObjectQuery alloc] initWithType:self.heartRateType predicate:predicate anchor:nil limit:HKObjectQueryNoLimit resultsHandler:^(HKAnchoredObjectQuery * _Nonnull query, NSArray<__kindof HKSample *>* _Nullable arrayOfSamples, NSArray<HKDeletedObject *>* _Nullable deletedObjects, HKQueryAnchor * _Nullable newAnchor, NSError * _Nullable error)
    {
        //Sets the query to call samplesReceived
        [self samplesReceived:arrayOfSamples];
    }];
    
    //Setup the update handler for this query
    [query setUpdateHandler:^(HKAnchoredObjectQuery *query, NSArray<HKSample *> *arrayOfSamples, NSArray<HKDeletedObject *> *deletedObjects, HKQueryAnchor *Anchor, NSError *error)
    {
        //Sets the update handler to call samplesReceived
        [self samplesReceived:arrayOfSamples];
    }];
    
    return query;
}

/// <summary>
/// Receives new heart rates.
/// Gets called when the watch receives a new sample.
/// </summary>
/// <param name="samples">An array of HKSamples that have been received.</param>
-(void) samplesReceived:(NSArray<HKSample *>*)samples
{
    //Get the sample
    HKQuantitySample *sample = (HKQuantitySample*)samples.lastObject;
    //Get the HKQuantity of the sample
    HKQuantity *quantity = sample.quantity;
    //Get the double value of the sample
    double quantityHeartRate = [quantity doubleValueForUnit:self.heartRateUnit];
    //Set the HeartRateLabel on the watch to show the received Heart Rate
    [self.HeartRateLabel setText:[NSString stringWithFormat:@"Heart Rate: %d", (int)quantityHeartRate]];
    //Set the value of self.heartRate to the value of the last sample received
    self.heartRate = (int)quantityHeartRate;
    //Sends the heart rate to the phone
    [self sendHeartRateToThePhone];
}

/// <summary>
/// Changes the workout status.
/// </summary>
-(void)workoutChange
{
    //If the workout is not running
    if(self.heartRateQuery == nil)
    {
        //Start the workout
        [self startWorkout];
        
    }
    else //if it is running
    {
        //Stop the workout
        [self stopWorkout];
    }
}

/// <summary>
/// Starts the workout.
/// </summary>
-(void) startWorkout
{
    //if the session is already started then return
    if(self.session != nil)
    {
        return;
    }
    
    NSError *error = nil;
    //Configure the HKWorkout
    HKWorkoutConfiguration *config = [[HKWorkoutConfiguration alloc] init];
    config.activityType = HKWorkoutActivityTypeCrossTraining;
    config.locationType = HKWorkoutSessionLocationTypeIndoor;
    
    //Initialize the HKWorkoutSesion with the config
    self.session = [[HKWorkoutSession alloc] initWithConfiguration:config error:&error];
    
    self.session.delegate = self;
    
    //Start the workoutSession
    [self.healthStore startWorkoutSession:self.session];
    
    //Set the hear rate query
    self.heartRateQuery = [self createStreamingQuery];
    //Start running the query
    [self.healthStore executeQuery:self.heartRateQuery];
}

/// <summary>
/// Stops the workout.
/// </summary>
-(void) stopWorkout
{
    //Stop the query
    [self.healthStore stopQuery:self.heartRateQuery];
    //Set the query to nil
    self.heartRateQuery = nil;
    //Reset the label text
    [self.HeartRateLabel setText:@"Heart Rate: 0"];
    //End the workout session
    [self.healthStore endWorkoutSession:self.session];
    //Set the session to nil
    self.session = nil;
}

/// <summary>
/// Starts the pedometer.
/// </summary>
-(void) startPedometer
{
    [self.StepCountText setText:@"Start walking..."];
     //Start the pedometer
     [self.pedometer startPedometerUpdatesFromDate:[NSDate date] withHandler:^(CMPedometerData * _Nullable pedometerData, NSError * _Nullable error)
     {
     	[self updatePedometerData:pedometerData];
     }];
}

/// <summary>
/// Stops the pedometer.
/// </summary>
-(void) stopPedometer
{
    //Stop the pedometer from updating
     [self.pedometer stopPedometerUpdates];
    //Reset the label text
    [self.StepCountText setText:@"Steps: 0"];
}

/// <summary>
/// Processes updates to the pedometer data.
/// Gets called when the watch receives pedometer data.
/// </summary>
/// <param name="pedometerData">A pointer to the current pedometer data.</param>
- (void)updatePedometerData:(CMPedometerData *)pedometerData
{
    //Create a formatter to format the data to two decimal places
    NSNumberFormatter *formatter = [[NSNumberFormatter alloc] init];
    formatter.maximumFractionDigits = 2;
    
    //Check if the step counting is available
    if([CMPedometer isStepCountingAvailable])
    {
        //Displays the current step count on the watch
        self.StepCountText.text = [NSString stringWithFormat:@"Steps: %@", [formatter stringFromNumber:pedometerData.numberOfSteps]];
        //Set the value of self.stepCount to the current step count value
        self.stepCount = pedometerData.numberOfSteps.intValue;
        //Sends the stepCount value to the phone
        [self sendStepCountToThePhone];
    }
    else
    {
        self.StepCountText.text = @"Steps Not avail";
    }
    
    //The code below can be uncommented if you would like to see the distance print
    //out on the watch app
    /*
    //Check if distance is available
    if([CMPedometer isDistanceAvailable])
    {
        //Displays the current total distance on the watch
        self.TypedMessageFromPhoneLabel.text = [NSString stringWithFormat:@"Dist: %@", [formatter stringFromNumber:pedometerData.distance]];
    }
    else
    {
        self.TypedMessageFromPhoneLabel.text = @"Dist Not avail";
    }
    */
}


/// <summary>
/// Gets called when the crown is rotated, will send the rotationalDelta
/// value to the phone
/// </summary>
/// <param name="crownSequencer">A reference to the crown sequencer.</param>
/// <param name="rotationalDelta">the rotational change since the last rotation.</param>
-(void) crownDidRotate:(WKCrownSequencer *)crownSequencer rotationalDelta:(double)rotationalDelta
{
    NSLog(@"Rotation: %f",rotationalDelta);
    NSString *crownRotation = [NSString stringWithFormat:@"%f",rotationalDelta];
    //Sends the rotational delta value to the phone
    [self SendStringToThePhone:crownRotation WithKey:@"CrownStatus"];
}

/// <summary>
/// Gets called when the crown stops rotating, will send an idle message to the phone
/// </summary>
/// <param name="crownSequencer">A reference to the crown sequencer.</param>
-(void) crownDidBecomeIdle:(WKCrownSequencer *)crownSequencer
{
    NSLog(@"IDLE");
    //Sends "IDLE" to the phone
    [self SendStringToThePhone:@"IDLE" WithKey:@"CrownStatus"];
}

/// <summary>
/// Gets called when sendMessageData is called on the phone
/// Is used for receiving images from the phone
/// </summary>
/// <param name="messageData">The NSData that was received.</param>
-(void)session:(WCSession *)session didReceiveMessageData:(NSData *)messageData replyHandler:(void (^)(NSData * _Nonnull))replyHandler
{
    NSLog(@"RECIEVED MESSAGE DATA");
    NSLog(@"%d", [messageData length]);
    
	//Get the image data from the sent data (ignores the last 4 bytes)
    NSData *receivedImagedata = [messageData subdataWithRange:NSMakeRange(0, messageData.length-4)];
    
    //Add the received data to the imageData
    [imageData appendData:receivedImagedata];
    
    char buffer[4];
    //Get the last 4 bytes, these bytes are used to check if the packet of data is the last packet for the image
	[messageData getBytes:buffer range:NSMakeRange(messageData.length-4, 4)];
	
    int finalPacketCheckCount = 0;
    //Check each of the four bytes
    for(int i = 0; i<4; i++)
    {
        char aByte = buffer[i];
        NSLog(@"Index %i", i);
        NSLog(@"%u", aByte);
        int a = aByte;
		
		//If the byte equals 1 then increase finalPacketCheckCount
        if(a == 1)
        {
            finalPacketCheckCount++;
        }
    }
    
	//If it is the final packet of data then the 4 bytes should each have been 1
    if(finalPacketCheckCount >= 4)
    {
		//Then make a UIImage out of the imageData that has been collected
        UIImage* image = [UIImage imageWithData:imageData];
        //Set the watchGroup background image to the created image
        [_watchGroup setBackgroundImage:image];
		//Reset the imageData
        [imageData setLength:0];
    }
}

/// <summary>
/// Gets called when transferUserInfo is called on the phone
/// Is used for receiving messsages from the phone
/// </summary>
/// <param name="userInfo">A dictionary that holds the messages received and a key with each message.</param>
- (void)session:(WCSession *)session didReceiveUserInfo:(NSDictionary<NSString *,id> *)userInfo
{
    NSLog(@"Received");
    NSLog(@"%@", userInfo);
    
    //If the message key is "Message" and the received message is "StartHeartRate"
    if([[userInfo objectForKey:@"Message"]  isEqual: @"StartHeartRate"])
    {
        //Change the workout
        [self workoutChange];
    }
    //If the message key is "Message" and the received message is "StopHeartRate"
    else if([[userInfo objectForKey:@"Message"]  isEqual: @"StopHeartRate"])
    {
        //Change the workout
        [self workoutChange];
    }
    //If the message key is "Message" and the received message is "StartPedometer"
    else if([[userInfo objectForKey:@"Message"]  isEqual: @"StartPedometer"])
    {
        //Start the pedometer
        [self startPedometer];
    }
    //If the message key is "Message" and the received message is "StopPedometer"
    else if([[userInfo objectForKey:@"Message"]  isEqual: @"StopPedometer"])
    {
        //Stop the pedometer
        [self stopPedometer];
    }
    //if the message key is "Message" and the received message is "Notification"
    else if([[userInfo objectForKey:@"Message"] isEqual:@"Notification"])
    {
        //Play the "Notification" haptic effect
        [[WKInterfaceDevice currentDevice] playHaptic:WKHapticTypeNotification];
    }
    //if the message key is "Message" and the received message is "DirectionUp"
    else if([[userInfo objectForKey:@"Message"] isEqual:@"DirectionUp"])
    {
        //Play the "DirectionUp" haptic effect
        [[WKInterfaceDevice currentDevice] playHaptic:WKHapticTypeDirectionUp];
    }
    //if the message key is "Message" and the received message is "DirectionDown"
    else if([[userInfo objectForKey:@"Message"] isEqual:@"DirectionDown"])
    {
        //Play the "DirectionDown" haptic effect
        [[WKInterfaceDevice currentDevice] playHaptic:WKHapticTypeDirectionDown];
    }
    //if the message key is "Message" and the received message is "Success"
    else if([[userInfo objectForKey:@"Message"] isEqual:@"Success"])
    {
        //Play the "Success" haptic effect
        [[WKInterfaceDevice currentDevice] playHaptic:WKHapticTypeSuccess];
    }
    //if the message key is "Message" and the received message is "Failure"
    else if([[userInfo objectForKey:@"Message"] isEqual:@"Failure"])
    {
        //Play the "Failure" haptic effect
        [[WKInterfaceDevice currentDevice] playHaptic:WKHapticTypeFailure];
    }
    //if the message key is "Message" and the received message is "Retry"
    else if([[userInfo objectForKey:@"Message"] isEqual:@"Retry"])
    {
        //Play the "Retry" haptic effect
        [[WKInterfaceDevice currentDevice] playHaptic:WKHapticTypeRetry];
    }
    //if the message key is "Message" and the received message is "Start"
    else if([[userInfo objectForKey:@"Message"] isEqual:@"Start"])
    {
        //Play the "Start" haptic effect
        [[WKInterfaceDevice currentDevice] playHaptic:WKHapticTypeStart];
    }
    //if the message key is "Message" and the received message is "Stop"
    else if([[userInfo objectForKey:@"Message"] isEqual:@"Stop"])
    {
        //Play the "Stop" haptic effect
        [[WKInterfaceDevice currentDevice] playHaptic:WKHapticTypeStop];
    }
    //if the message key is "Message" and the received message is "Click"
    else if([[userInfo objectForKey:@"Message"] isEqual:@"Click"])
    {
        //Play the "Click" haptic effect
        [[WKInterfaceDevice currentDevice] playHaptic:WKHapticTypeClick];
    }
    //Else if the message key is "Input"
    else if([userInfo objectForKey:@"Input"] != nil)
    {
        NSString *labelText = [NSString stringWithFormat:@"Action: %@",[userInfo objectForKey:@"Input"]];
        //Then display the Input message to show which button was pressed on the phone (Button A or Button B)
        [self.buttonStatusLabel setText:labelText];
    }
    //Else if the user is sending a background fileName
    else if([userInfo objectForKey:@"Background"] != nil)
    {
		//Find the path to the png that matches the text returned by "[userInfo objectForKey:@"Background"]"
        //Basically find the path for the png that matches the filename that is sent
        NSString *fullPath = [[NSBundle mainBundle] pathForResource:[userInfo objectForKey:@"Background"] ofType:@"png"];
		//Create an image out of the png at the path "fullPath" and set the watch background to the image
        UIImage *image  = [UIImage imageWithContentsOfFile:fullPath];
        [_watchGroup setBackgroundImage:image];
    }
    else
    {
        //Else display the message that was received (this is the message that was typed out by the user)
        [self.TypedMessageFromPhoneLabel setText:[userInfo objectForKey:@"Message"]];
    }
}

/// <summary>
/// Gets called when Button C is pressed
/// </summary>
- (IBAction)ButtonCPressed
{
    //Sends "Button C" to the phone
    [self SendStringToThePhone:@"Button C" WithKey:@"ButtonPressed"];
}

/// <summary>
/// Gets called when Button D is pressed
/// </summary>
- (IBAction)ButtonDPressed
{
    //Sends "Button D" to the phone
    [self SendStringToThePhone:@"Button D" WithKey:@"ButtonPressed"];
}

/// <summary>
/// Send "message" to the watch with "key".
/// </summary>
/// <param name="message">the NSString* that will be sent.</param>
/// <param name="key">The key that gets passed with the message.</param>
-(void)SendStringToThePhone:(NSString*) message WithKey:(NSString*)key
{
    //Create a dictionary with the key and message
    NSDictionary *applicationData = [[NSDictionary alloc] initWithObjects:@[message] forKeys:@[key]];
    
    //Sends it to the phone
    [[WCSession defaultSession] sendMessage:applicationData
                               replyHandler:^(NSDictionary *reply){
                                   NSLog(@"GOOD JOB");
                               }
                               errorHandler:^(NSError *NSError){
                                   NSLog(@"%@", NSError);
                               }
     ];

}

/// <summary>
/// Send "numberToSend" to the watch with "key".
/// </summary>
/// <param name="numberToSend">the int that will be sent.</param>
/// <param name="key">The key that gets passed with the number.</param>
-(void)SendIntegerToThePhone:(int) numberToSend WithKey:(NSString*)key
{
    //Create a dictionary with the key and number
    NSDictionary *applicationData = [[NSDictionary alloc] initWithObjects:@[[NSString stringWithFormat:@"%d", numberToSend]] forKeys:@[key]];
    
    //Sends it to the phone
    [[WCSession defaultSession] sendMessage:applicationData
                               replyHandler:^(NSDictionary *reply){
                                   NSLog(@"Worked");
                               }
                               errorHandler:^(NSError *NSError){
                                   NSLog(@"%@", NSError);
                               }
     ];
    
}

- (void)dealloc {
    [_StepCountText release];
    [super dealloc];
}
@end

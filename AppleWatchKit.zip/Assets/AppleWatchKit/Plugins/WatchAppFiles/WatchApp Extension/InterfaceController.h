//
//  InterfaceController.h
//
// Manages and communicates with the interface of the watch
//

#import <WatchKit/WatchKit.h>
#import <Foundation/Foundation.h>
#import <HealthKit/HealthKit.h>
#import <WatchConnectivity/WatchConnectivity.h>
#import <CoreMotion/CoreMotion.h>

@interface InterfaceController : WKInterfaceController <WCSessionDelegate,HKWorkoutSessionDelegate,WKCrownDelegate>
//Shows the status of the button that was pressed on the phone (shows an A or B)
@property (unsafe_unretained, nonatomic) IBOutlet WKInterfaceLabel *buttonStatusLabel;
//Shows the message that the user sends to the watch from the phone
//Will also display the distance travelled when using the pedometer and if the code for distance has been uncommented
@property (unsafe_unretained, nonatomic) IBOutlet WKInterfaceLabel *TypedMessageFromPhoneLabel;
//Displays the heart rate when the user is recording heart rate
@property (unsafe_unretained, nonatomic) IBOutlet WKInterfaceLabel *HeartRateLabel;
//Displays the step count when the user is using the pedometer functionality
@property (retain, nonatomic) IBOutlet WKInterfaceLabel *StepCountText;
//Stores a reference to a CMPedometer, that is used for the pedometer functionality of the watch app
@property (strong, nonatomic) CMPedometer *pedometer;

//Mutable data that holds the imageData sent to the watch by the user
//Used for receiving images from the phone
@property (nonatomic, strong) NSMutableData *imageData;
//Integer that stores the currently received heart rate value from the watch
@property (nonatomic, assign) int heartRate;
//Integer that stores the current step count value from the watch
@property (nonatomic, assign) int stepCount;
//A reference to the HKHealthStore
@property (nonatomic, strong) HKHealthStore *healthStore;
//HKQuantityType used for heart rate recording
@property (nonatomic, strong) HKQuantityType *heartRateType;
//HKUnit used for heart rate recording
@property (nonatomic, strong) HKUnit *heartRateUnit;
//Holds a reference to the query that should run when recording the heart rate
@property (nonatomic, strong) HKQuery *heartRateQuery;
//A reference to the HKWorkoutSession that is used when starting a workout (required for getting the heart rate to record)
@property (nonatomic, strong) HKWorkoutSession *session;
//Refers to the WKInterfaceGroup on the Watch, allows the background image to be changed
//Is currently the only way to change the watch's background image through code
@property (unsafe_unretained, nonatomic) IBOutlet WKInterfaceGroup *watchGroup;

//Sends the heart rate value to the phone
- (void)sendHeartRateToThePhone;
//Sends the step count value to the phone
- (void)sendStepCountToThePhone;
//Changes the status of the workout that is used for the heart rate
- (void) workoutChange;
//Starts the workout
- (void) startWorkout;
//Stops the workout
- (void) stopWorkout;
//Starts the pedometer
- (void) startPedometer;
//Stops the pedometer
- (void) stopPedometer;
//Triggers when Button "C" is pressed on the watch
- (IBAction)ButtonCPressed;
//Triggers when Button "D" is pressed on the watch
- (IBAction)ButtonDPressed;
//Sends the "message" to the phone with "key" key value
- (void)SendStringToThePhone:(NSString*) message WithKey:(NSString*)key;
//Sends the "numberToSend" to the phone with "key" key value
- (void)SendIntegerToThePhone:(int) numberToSend WithKey:(NSString*)key;
@end

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class main : MonoBehaviour {

	public Button button1;
	public Button button2;

	public Text text1;
	public Text text2;

	private float timer1 = 0f;
	private float timer2 = 0f;

	public Texture2D[] textures = null;

	private void Start()
	{
	}

	public void OnClickGain1()
	{
		UnityWatchAppManager.Gain("1");

		timer1 = 3;
		button1.interactable = false;
	}

	public void OnClickGain2()
	{
		UnityWatchAppManager.Gain("2");

		timer2 = 2;
		button2.interactable = false;
	}

	private void Update()
	{
		if (timer1 > 0)
		{
			timer1 -= Time.deltaTime;
			text1.text = timer1.ToString();
			if (timer1 <= 0)
			{
				button1.interactable = true;
				text1.text = "planet1";
			}
		}

		if (timer2 > 0)
		{
			timer2 -= Time.deltaTime;
			text2.text = timer2.ToString();
			if (timer2 <= 0)
			{
				button2.interactable = true;
				text2.text = "planet2";
			}
		}
	}
}

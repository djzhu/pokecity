#import "UnityToXcodeBridge.h"

#pragma mark - PRIVATE -

@implementation UnityToXcodeBridge

static UnityToXcodeBridge * unityToXcode;

+ (UnityToXcodeBridge*) instance
{
    @synchronized (self)
    {
        if(unityToXcode == nil)
        {
            unityToXcode = [[self alloc] init];
        }
    }
    return unityToXcode;
}

-(id) init
{
    return [super init];
}

- (void)activeSession
{
    //Check if WatchConnectivity is supported by this device
    if([WCSession isSupported])
    {
        //Activate the session
        WCSession *session = [WCSession defaultSession];
        session.delegate = self;
        [session activateSession];
        
        NSLog(@"iphone init session");
    }
    else
    {
        NSLog(@"WatchConnectivity is not supported on this device");
    }
}

//- (void)didDeactivate
//{
//    // This method is called when watch view controller is no longer visible
//    //[super didDeactivate];
//}
//- (void)sessionDidBecomeInactive:(WCSession *)session
//{
//}
//- (void)session:(nonnull WCSession *)session activationDidCompleteWithState:(WCSessionActivationState)activationState error:(nullable NSError *)error {
//}

- (void)session:(WCSession *)session didReceiveMessage:(NSDictionary<NSString *,id> *)message replyHandler:(void (^)(NSDictionary<NSString *,id> * _Nonnull))replyHandler
{
    NSLog(@"iphone reveive");
    if([message objectForKey:@"init"] != nil)
    {
        UnitySendMessage("UnityWatchAppManager", "WatchAppInit", "");
    }
    else if([message objectForKey:@"gain"] != nil)
    {
        NSString* value = [message objectForKey:@"gain"];
        const char* chars = [value UTF8String];
        UnitySendMessage("UnityWatchAppManager", "WatchAppGain", chars);
    }
}

- (void)sendToWatch:(const char*) message WithKey:(NSString*) key
{
    NSLog(@"iphone send %@:%s", key, message);
//    NSError *error;
//    if(![[WCSession defaultSession] transferUserInfo:@{key : [NSString stringWithUTF8String:message]}])
//    {
//        NSLog(@"sendToWatch failed with error %@", error);
//    }
    NSString* msg = [NSString stringWithUTF8String:message];
    NSDictionary *applicationData = [[NSDictionary alloc] initWithObjects:@[msg] forKeys:@[key]];
    [[WCSession defaultSession] sendMessage:applicationData
                               replyHandler:^(NSDictionary *reply){
                                   NSLog(@"GOOD JOB");
                               }
                               errorHandler:^(NSError *NSError){
                                   NSLog(@"%@", NSError);
                               }
     ];
}

- (void)sendImageToWatch:(NSData*)dataToSend WithKey:(char) key
{
    if([[WCSession defaultSession] isReachable])
    {
        char bytes[1] = { key };
        NSMutableData *mutableData = [NSMutableData dataWithBytes:bytes length:sizeof(bytes)];
        [mutableData appendBytes:dataToSend.bytes length:dataToSend.length];
        [[WCSession defaultSession] sendMessageData:[NSData dataWithData:mutableData]
                                       replyHandler:^(NSData *reply){
                                           NSLog(@"Successful");
                                       }
                                       errorHandler:^(NSError *NSError){
                                           NSLog(@"%@",NSError);
                                       }
         ];}
    else
    {
        NSLog(@"Watch session is unreachable");
    }
    
    
    
//    //Number of pieces to break the data into
//    int pieces = 4;
//
//    //Break up the data into small enough sizes to send to the watch
//    NSData *chunkOfImageData = [dataToSend subdataWithRange:NSMakeRange(0, dataToSend.length/pieces)];
//
//    //Add the data to mutableData (this way we can add bytes to the end of it)
//    NSMutableData *mutableData = [NSMutableData dataWithBytes:chunkOfImageData.bytes length:chunkOfImageData.length];
//
//    for(int i = 0; i<pieces; i++)
//    {
//        //Set the data for this chunk
//        chunkOfImageData = [dataToSend subdataWithRange:NSMakeRange((i * dataToSend.length) / pieces, dataToSend.length / pieces)];
//        //Set mutableData to this chunk of data
//        mutableData = [NSMutableData dataWithBytes:chunkOfImageData.bytes length:chunkOfImageData.length];
//        //Create an array of 4 bytes all set to zero
//        //These bytes will be extracted from the received data on the watch to determine
//        //if the packet of data the watch receives is the last packet for the image or not
//        char bytes[4] = {0,0,0,0};
//        //If sending the last piece of data then set the bytes to one
//        if(i == pieces-1)
//        {
//            bytes[0] = 1;
//            bytes[1] = 1;
//            bytes[2] = 1;
//            bytes[3] = 1;
//        }
//
//        //Add the bytes onto the end of the mutableData
//        [mutableData appendBytes:bytes length:sizeof(bytes)];
//
//        //If the watch is reachable
//        if([[WCSession defaultSession] isReachable])
//        {
//            //Send the data to the watch
//            [[WCSession defaultSession] sendMessageData:[NSData dataWithData:mutableData]//Create an NSData object out of the NSMutableData object
//                                           replyHandler:^(NSData *reply){
//                                               NSLog(@"Successful");
//                                           }
//                                           errorHandler:^(NSError *NSError){
//                                               NSLog(@"%@",NSError);
//                                           }
//             ];}
//        else
//        {
//            NSLog(@"Watch session is unreachable");
//        }
//    }
}

@end


#pragma mark - EXTERN -

extern "C"
{
    
    void active()
    {
        [[UnityToXcodeBridge instance] activeSession];
    }

    void gain(const char* msg)
    {
        [[UnityToXcodeBridge instance] sendToWatch:msg WithKey:@"gain"];
    }
    
    void sendImage(UInt8* texture, int width, int height, char key)
    {
        NSInteger dataLength = width * height * sizeof(UInt8);
        NSData* imageData = [[NSData alloc] initWithBytes:(void*)texture length:dataLength];
        [[UnityToXcodeBridge instance] sendImageToWatch:imageData WithKey:key];
    }

}

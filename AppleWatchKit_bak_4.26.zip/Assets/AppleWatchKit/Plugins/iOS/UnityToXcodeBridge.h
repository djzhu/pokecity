#import <Foundation/Foundation.h>
#import <WatchConnectivity/WatchConnectivity.h>

@interface UnityToXcodeBridge : NSObject <WCSessionDelegate>


+ (UnityToXcodeBridge*) instance;

- (id)  init;

- (void)activeSession;

- (void)sendToWatch:(const char*) message WithKey:(NSString*) key;

- (void)sendImageToWatch:(NSData*)dataToSend WithKey:(char) key;

@end

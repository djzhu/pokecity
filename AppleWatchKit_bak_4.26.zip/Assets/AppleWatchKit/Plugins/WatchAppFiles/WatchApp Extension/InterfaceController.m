#import "InterfaceController.h"

@implementation InterfaceController

- (void)awakeWithContext:(id)context
{
    NSLog(@"watch init content");
    [super awakeWithContext:context];
}

- (void)willActivate
{
    [super willActivate];
    
    if([WCSession isSupported])
    {
        //Activate the session
        WCSession *session = [WCSession defaultSession];
        session.delegate = self;
        [session activateSession];
        
        NSLog(@"watch init session");
    }
    else
    {
        NSLog(@"WatchConnectivity is not supported on this device");
    }
    
}

- (void)didDeactivate
{
    // This method is called when watch view controller is no longer visible
    [super didDeactivate];
}

- (void)session:(nonnull WCSession *)session activationDidCompleteWithState:(WCSessionActivationState)activationState error:(nullable NSError *)error
{
    NSLog(@"watch complete init session");
    // 告诉iphone需要初始化, 让iphone传一些图片过来
    [self sendToiPhone:@"" WithKey:@"init"];
}

- (void)session:(WCSession *)session didReceiveMessage:(NSDictionary<NSString *,id> *)message replyHandler:(void (^)(NSDictionary<NSString *,id> * _Nonnull))replyHandler
{
    NSLog(@"watch receive message");
    
    if([message objectForKey:@"gain"] != nil)
    {
        NSString* value = [message objectForKey:@"gain"];
//        if ([value  isEqual: @"1"])
//        {
//            [self.button1 setEnabled:false];
//        }
//        else if ([value  isEqual: @"2"])
//        {
//            [self.button2 setEnabled:false];
//        }
    }
}

-(void)session:(WCSession *)session didReceiveMessageData:(NSData *)messageData replyHandler:(void (^)(NSData * _Nonnull))replyHandler
{
    NSLog(@"watch receive data");
    NSLog(@"%d", [messageData length]);
    
    char buffer[1];
    [messageData getBytes:buffer range:NSMakeRange(0, 1)];
    
    NSData* receivedImagedata = [messageData subdataWithRange:NSMakeRange(1, messageData.length - 1)];
    
    int key = buffer[0];
    if (key == 1)
    {
        NSMutableData* imageData = [[NSMutableData alloc] init];
        [imageData appendData:receivedImagedata];
        UIImage* image = [UIImage imageWithData:imageData];
        [self.childrenGroup setBackgroundImage:image];
        
        //WKInterfaceImage
        //WKInterfaceGroup* gp = [WKInterfaceGroup init];
        //WKInterfaceGroup* group = [self.childrenGroup copy];
    }
    
//    //Get the image data from the sent data (ignores the last 4 bytes)
//    NSData *receivedImagedata = [messageData subdataWithRange:NSMakeRange(0, messageData.length-4)];
//
//    //Add the received data to the imageData
//    [imageData appendData:receivedImagedata];
//
//    char buffer[4];
//    //Get the last 4 bytes, these bytes are used to check if the packet of data is the last packet for the image
//    [messageData getBytes:buffer range:NSMakeRange(messageData.length-4, 4)];
//
//    int finalPacketCheckCount = 0;
//    //Check each of the four bytes
//    for(int i = 0; i<4; i++)
//    {
//        char aByte = buffer[i];
//        NSLog(@"Index %i", i);
//        NSLog(@"%u", aByte);
//        int a = aByte;
//
//        //If the byte equals 1 then increase finalPacketCheckCount
//        if(a == 1)
//        {
//            finalPacketCheckCount++;
//        }
//    }
//
//    //If it is the final packet of data then the 4 bytes should each have been 1
//    if(finalPacketCheckCount >= 4)
//    {
//        //Then make a UIImage out of the imageData that has been collected
//        UIImage* image = [UIImage imageWithData:imageData];
//        //Set the watchGroup background image to the created image
//        [_watchGroup setBackgroundImage:image];
//        //Reset the imageData
//        [imageData setLength:0];
//    }
}

//
//- (IBAction)Button1Pressed
//{
//    //Sends "Button C" to the phone
//    [self sendToiPhone:@"1" WithKey:@"gain"];
//    [self.button1 setEnabled:false];
//}
//
//- (IBAction)Button2Pressed
//{
//    //Sends "Button D" to the phone
//    [self sendToiPhone:@"2" WithKey:@"gain"];
//    [self.button2 setEnabled:false];
//}

-(void)sendToiPhone:(NSString*) message WithKey:(NSString*)key
{
    NSLog(@"watch send msg: %@", message);
    
    //Create a dictionary with the key and message
    NSDictionary *applicationData = [[NSDictionary alloc] initWithObjects:@[message] forKeys:@[key]];
    
    //Sends it to the phone
    [[WCSession defaultSession] sendMessage:applicationData
                               replyHandler:^(NSDictionary *reply){
                                   NSLog(@"GOOD JOB");
                               }
                               errorHandler:^(NSError *NSError){
                                   NSLog(@"%@", NSError);
                               }
     ];
    
}

// @[[NSString stringWithFormat:@"%d", numberToSend]]

- (void)dealloc {
    [super dealloc];
}
@end

#import <WatchKit/WatchKit.h>
#import <Foundation/Foundation.h>
#import <WatchConnectivity/WatchConnectivity.h>

@interface InterfaceController : WKInterfaceController <WCSessionDelegate>

//@property (unsafe_unretained, nonatomic) IBOutlet WKInterfaceLabel *label1;
//@property (unsafe_unretained, nonatomic) IBOutlet WKInterfaceLabel *label2;
//
//@property (unsafe_unretained, nonatomic) IBOutlet WKInterfaceButton *button1;
//@property (unsafe_unretained, nonatomic) IBOutlet WKInterfaceButton *button2;

@property (unsafe_unretained, nonatomic) IBOutlet WKInterfaceGroup *parentGroup;
@property (unsafe_unretained, nonatomic) IBOutlet WKInterfaceGroup *childrenGroup;

//@property (nonatomic, strong) NSMutableData *imageData;

//- (IBAction)ButtonCPressed;
//
//- (IBAction)ButtonDPressed;

- (void)sendToiPhone:(NSString*) message WithKey:(NSString*)key;

@end

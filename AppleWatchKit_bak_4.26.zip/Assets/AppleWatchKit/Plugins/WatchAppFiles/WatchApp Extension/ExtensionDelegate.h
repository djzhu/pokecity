//
//  ExtensionDelegate.h
//  WatchApp Extension
//
//  Created by James Martin on 2017-01-16.
//
//

//#import <WatchKit/WatchKit.h>
//
//@interface ExtensionDelegate : NSObject <WKExtensionDelegate>
//
//@end

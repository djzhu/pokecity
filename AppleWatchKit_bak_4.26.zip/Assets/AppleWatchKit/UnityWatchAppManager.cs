﻿using UnityEngine;
using System.Runtime.InteropServices;

public class UnityWatchAppManager : MonoBehaviour
{
	public static UnityWatchAppManager Instance { get; private set; }

	private void Awake()
	{
		Instance = this;
		DontDestroyOnLoad(gameObject);

		#if UNITY_IOS && !UNITY_EDITOR
		// active apple watch connect on iphone
		active();
		#endif
	}


	#if UNITY_IOS && !UNITY_EDITOR

	[DllImport("__Internal")]
	private static extern void active();

	[DllImport("__Internal")]
	private static extern void gain(string msg);

	[DllImport("__Internal")]
	private static extern void sendImage(byte[] texture, int width, int height, byte key);

	#endif

	// iphone -> watch

	public static void Gain(string key)
	{
		#if UNITY_IOS && !UNITY_EDITOR

		// disable watch button
		gain(key);

		#endif
	}

	// watch -> iphone

	private void WatchAppInit(string value)
	{
		#if UNITY_IOS && !UNITY_EDITOR

		// watchapp 启动的时候从 app 中获取图片资源及相关信息用来初始化
		Texture2D tex = GameObject.Find("Canvas").GetComponent<main>().textures[0];
		sendImage(tex.EncodeToPNG(), tex.width, tex.height, 0x01);

		#endif
	}

	private void WatchAppGain(string value)
	{
		// 客户端 gain 逻辑
		Debug.Log("unity WatchAppGain:" + value);
		if (value == "1")
		{
			GameObject.Find("Canvas").GetComponent<main>().OnClickGain1();
		}
		else if (value == "2")
		{
			GameObject.Find("Canvas").GetComponent<main>().OnClickGain2();
		}

		// disable watch button
		Gain(value);
	}

}